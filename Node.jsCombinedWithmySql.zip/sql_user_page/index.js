//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
const express = require("express");
const db = require("./routes/db-config");
const app = express();
const cookieParser = require("cookie-parser");
const PORT = process.env.PORT || 5000;

// Middleware
app.use("/js", express.static(__dirname + "/public/js"));
app.use("/css", express.static(__dirname + "/public/css"));
app.set("view engine", "ejs");
app.set("views", "./views");
app.use(cookieParser());
app.use(express.json());

// Database connection
db.connect((err) => {
    if (err) throw err;
    console.log("Database connected");
});

// Routes
app.use("/", require("./routes/pages")); // Pages routes
app.use("/api", require("./controllers/auth")); // Authentication routes
app.use("/api", require("./controllers/addproduct")); // Addproduct routes
app.use("/api", require("./controllers/review")); // Review routers



// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
