//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
const express = require("express");
const loggedIn = require("../controllers/loggedIn");
const logout = require("../controllers/logout");
const db = require("../routes/db-config");
const router = express.Router();

router.get("/", loggedIn, (req, res) => {
    if (req.user) {
        res.render("index", { status: "loggedIn", user: req.user });
    } else {
        res.render("index", { status: "no", user: "nothing" });
    }
});

router.get("/register", (req, res) => {
    res.sendFile("register.html", { root: "./public" });
});

router.get("/about", (req, res) => {
    res.sendFile("about.html", { root: "./public" });
});

router.get("/index", (req, res) => {
    res.sendFile("index.html", { root: "./public" });
});
router.get("/api/products", (req, res) => {
    const sql = 'SELECT * FROM addproduct';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            res.status(500).json({ error: 'Error fetching data' });
        } else {
            res.json(results);
        }
    });
});
router.get("/api/seereviews", (req, res) => {
    const sql = 'SELECT * FROM review';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching data:', err);
            res.status(500).json({ error: 'Error fetching data' });
        } else {
            res.json(results);
        }
    });
});

router.get("/products", (req, res) => {
    
    res.sendFile("products.html", { root: "./public" }); 
});
router.get("/seereviews", (req, res) => {
    
    res.sendFile("seereviews.html", { root: "./public" }); 
});

router.get("/addproduct", (req, res) => {
    // Render the add product form HTML
    res.sendFile("addproduct.html", { root: "./public" });
});
// Route to fetch data from addproduct table

router.get("/review", (req, res) => {
    // Render the review form HTML
    res.sendFile("review.html", { root: "./public" });
});

router.get("/login", (req, res) => {
    res.sendFile("login.html", { root: "./public/" });
});

router.get("/logout", logout);

module.exports = router;
