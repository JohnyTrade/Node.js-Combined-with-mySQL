//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
const db = require("../routes/db-config");

const addproduct = async (req, res) => {
    const { pname, pprice } = req.body;

    // Check if pname and pprice are provided
    if (!pname || !pprice) {
        return res.json({ status: "error", error: "Please provide pname and pprice" });
    }

    // Insert pname and pprice into the database
    db.query('INSERT INTO addproduct (pname, pprice) VALUES (?, ?)', [pname, pprice], (error, result) => {
        if (error) {
            console.error('Error adding product:', error);
            return res.status(500).json({ status: "error", error: "Error adding product" });
        }
        
        // Return success response if the product is added successfully
        return res.json({ status: "success", success: "Product has been added!" });
    });
};

module.exports = addproduct;
