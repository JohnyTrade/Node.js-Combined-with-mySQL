//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
const express = require("express");
const register = require("./register");
const login = require("./login");
const addproduct = require("./addproduct"); // Import the addproduct route handler
const review = require("./review");


const router = express.Router();



// Define routes
router.post("/review", review); // Route for adding a review
router.post("/addproduct", addproduct); // Route for adding a product
router.post("/register", register); // Route for registering
router.post("/login", login); // Route for logging in

module.exports = router;
