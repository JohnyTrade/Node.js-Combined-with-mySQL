//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
const logout = (req, res) =>{
res.clearCookie("userRegistered");
res.redirect("/");
}
module.exports = logout;