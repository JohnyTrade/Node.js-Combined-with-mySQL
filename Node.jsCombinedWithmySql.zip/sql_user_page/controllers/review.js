//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
const db = require("../routes/db-config");

const review = async (req, res) => {
    const { rreview } = req.body;

    // Check if rreview are provided
    if (!rreview) {
        return res.json({ status: "error", error: "Please provide rreview" });
    }

    // Insert rreview into the database
    db.query('INSERT INTO review (rreview) VALUES (?)', [rreview], (error, result) => {
        if (error) {
            console.error('Error adding review:', error);
            return res.status(500).json({ status: "error", error: "Error adding review" });
        }

        // Return success response if the review is added successfully
        return res.json({ status: "success", success: "Review has been added!" });
    });
};

module.exports = review;
