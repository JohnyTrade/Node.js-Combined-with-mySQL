//שם: ג'ון פול מלשה
//ת'ז: 206941304
//שם: מעין אפשטיין
//ת'ז:208159137
form.addEventListener("submit", () => {
    const addproduct = {
        pname: pname.value,
        pprice: pprice.value
    };
    fetch("/api/addproduct", {
        method: "POST",
        body: JSON.stringify(addproduct),
        headers: {
            "Content-Type": "application/json"
        }
    }).then(res => res.json())
    .then(data => {
        if (data.status == "error") {
            success.style.display = "none"
            error.style.display = "block"
            error.innerText = data.error
        } else {
            error.style.display = "none"
            success.style.display = "block"
            success.innerText = data.success
        }
    })
})
